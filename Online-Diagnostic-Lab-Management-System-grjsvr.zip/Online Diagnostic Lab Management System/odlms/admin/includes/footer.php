<div class="wrap p-t-0">
    <footer class="app-footer">
      <div class="clearfix">
          <div class="copyright pull-left">Online Diagnostic Lab Management System @ 2020</div>
      </div>
    </footer>
  </div>